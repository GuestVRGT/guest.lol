guest.lol Desktop (Windows)
===========================

This project wraps the supplied guest.lol HTML app in a desktop window and builds a Windows x64 installer.

BUILD THE .EXE ON WINDOWS
1. Install Node.js LTS from https://nodejs.org/ if it is not already installed.
2. Extract this folder from the ZIP.
3. Double-click build-windows.bat.
4. When it finishes, find the installer in dist\guest.lol-Setup-1.0.0.exe.

To run the app during development instead:
1. Open a terminal in this folder.
2. Run: npm install
3. Run: npm start

Notes:
- The app's existing HTML/JavaScript is included as index.html.
- The supplied HTML references GIF.js and Google Fonts over the internet, so those features/fonts may require an internet connection.
- This build recipe creates a Windows x64 installer; this Linux environment cannot directly produce/test the final Windows .exe here.
