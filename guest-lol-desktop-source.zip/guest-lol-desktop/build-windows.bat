@echo off
setlocal
cd /d "%~dp0"
echo Installing app build dependencies...
call npm install
if errorlevel 1 goto failed
echo Building guest.lol Windows installer...
call npm run dist
if errorlevel 1 goto failed
echo.
echo Done! Look in the dist folder for guest.lol-Setup-1.0.0.exe
pause
exit /b 0
:failed
echo.
echo Build failed. Check that Node.js LTS is installed and internet access is available.
pause
exit /b 1
